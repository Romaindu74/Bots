from .Bot import Bot

class Setup:
    async def setup(Bot: Bot) -> bool:...