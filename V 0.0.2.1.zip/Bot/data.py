import os
from typing import Any, Union
from .Utils import Open, Save

class DataBase:
    def __init__(self, path: str = os.path.abspath('.')):
        self.path = '{0}/User/Bots/'.format(path)

    @property
    def fetch_all(self) -> list[dict[str, Union[str, int, bool, Any]]]:
        result = []
        os.makedirs(self.path, 777, True)
        for i in Open('{0}/Bots.json'.format(self.path)).get('Bots', []):
            result.append(Open('{0}/{1}/Main.json'.format(self.path, i)))
        return result

    def insert(self, data: dict[str, str] = {}) -> None:
        if data == {}:
            return
        os.makedirs(self.path, 777, True)
        Save('{0}/{1}/Main.json'.format(self.path, data.get('Id')), data)

    def delete(self,what_delete,app,x=None) -> None:
        if what_delete == "all_row":
            if len(self.fetch_all) >= 1:
                for i in range(len(app.row_data)):
                    app.remove_row(app.row_data[-1])
                os.removedirs(self.path)
        elif what_delete == "id":
            if len(app.row_data) >= 1 and os.path.exists(self.path+'/'+x):
                os.removedirs(self.path+'/'+x)
                os.makedirs(self.path, 777, True)
                data = Open('{0}/Bots.json'.format(self.path), {"Bots":[]})
                bots: list[str] = data.get('Bots')
                bots.remove(x)
                Save('{0}/Bots.json'.format(self.path), {"Bots": bots})

    def update(self,id,new_value) -> None:
        pass