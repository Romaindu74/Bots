from .Logger import Log, Logger
from .UpDate import UpDate
from .Main   import Main

Ready: bool