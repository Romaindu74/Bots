from .UpDate import UpDate
from .Logger import Log, Logger
from .Main   import Main

Ready: bool