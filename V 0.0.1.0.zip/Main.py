import sys
import datetime

def Log(text: str = '', _exit: bool = False, **options):
    context = '[{0}] {1}'.format(str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),str(text))
    print(context)

    try:
        with open('Logs.txt', 'a') as f:
            f.write(str(context)+'\n')
            f.close()

    except FileNotFoundError:
        with open('Logs.txt', 'w+') as f:
            f.write(str(context)+'\n')
            f.close()

    except Exception as e:
        raise Exception(str(e))

    if _exit:
        sys.exit(0)

try:
    import Bot
except Exception as e:
    Log(e, True)

if not Bot.UpDate.Start():
    Log('The update could not be done')

if Bot.Ready:
    Bot.Main()