from .Logger    import Log
from .GetLang   import Get_Lang
from .Utils     import Save, Open, MISSING
from .Bot       import Bot

import os

try:
    import requests
except ImportError:
    Log(50, Get_Lang.get('0.0.0.0.0').format(Name = 'requests'), True)
except Exception as e:
    Log(50, Get_Lang.get('0.0.0.0.1').format(File = __file__, Error = str(e)), True)


class Options:
    def __init__(self) -> None:
        self._info: dict          = {
            'Windows-Title': 'RPA-Bot\'s'
        }

        self._path: str           = os.path.abspath('.')
        self._bots: dict[Bot]     = {}

        self._initialized: list   = [False, 0]

        if self.Start_Bots():
            self._initialized     = [True, 2]

        self._sessions            = requests.Session()

    def Start_Bots(self) -> bool:
        try:
            Log(20, Get_Lang.get('0.0.1.7.0'))
            if not os.path.exists('{0}/User/Bots/Bots.json'.format(self.Path)):
                os.makedirs('{0}/User/Bots'.format(self.Path), exist_ok = True)
                Save('{0}/User/Bots/Bots.json'.format(self.Path), {'Bots': []})
        except Exception as e:
            self._initialized = [False, 1, str(e)]
            return False

        for Bot_ in Open('{0}/User/Bots/Bots.json'.format(self.Path), {'Bots': []}).get('Bots', []):
            Bot__ = Bot(Bot_, self)

            if Bot__.check:
                Bot__.start()
                self._bots[Bot_] = Bot__

        return True

    def add_bot(self, Id: str = MISSING) -> None:
        if not Id == MISSING:
            Bot__ = Bot(Id, self)
            if Bot__.check:
                Bot__.start()
                self._bots[Id] = Bot__

    @property
    def sessions(self) -> requests.Session:
        return self._sessions

    @property
    def Info(self) -> dict:
        return self._info

    @Info.setter
    def Info(self, value: dict = MISSING) -> dict:
        if not value == MISSING:
            self._info = value
        return self._info


    @property
    def Bots(self) -> dict[Bot]:
        return self._bots

    @Bots.setter
    def Bots(self, value: dict[Bot] = MISSING) -> dict[Bot]:
        if not value == MISSING:
            self._bots = value
        return self._bots

    @property
    def Path(self) -> str:
        return self._path

    @property
    def Initialized(self) -> list:
        return self._initialized

    @property
    def URL(self) -> str:
        return 'https://reclinable-supervis.000webhostapp.com/'
