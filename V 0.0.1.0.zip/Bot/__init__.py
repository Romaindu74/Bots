from .UpDate import UpDate

Ready = False
try:
    from .Main import Main
    Ready = True
except Exception as e:
    raise Exception(str(e))