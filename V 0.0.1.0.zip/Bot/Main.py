from .Interface import Interface
from .Options   import Options

class Main(object):
    def __init__(self) -> None:
        options = Options()

        while not options.Initialized[0]:
            if options.Initialized[1] == 1:
                raise Exception(options.Initialized[2])

        self.Interface = Interface(options)
        self.Interface.start()

        while not self.Interface.Initialized:
            if not self.Interface.check:
                exit()

        self.Interface.Start()

        self.Interface.join()