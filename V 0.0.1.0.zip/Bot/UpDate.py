import json
import pip
import os

from time import monotonic
from .Logger import Log


try:
    from requests import Session
except ImportError:
    pip.main(['install', 'requests'])
    from pip._vendor.requests import Session
except Exception as e:
    Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e), True)


class UpDate:
    URL = 'https://reclinable-supervis.000webhostapp.com/'
    sessions = Session()

    @classmethod
    def Start(self) -> bool:
        self.path = str(os.path.abspath('.'))

        Log(20, 'Checking for bot updates')
        if self.check_modules(self):
            if self.install(self):
                self.sessions.close()
                return True

        self.sessions.close()
        return True

    def check_modules(self) -> bool:
        Log(20, 'Module being checked')
        r = self.sessions.get('{0}bot/modules'.format(self.URL))
        try:
            modules = r.json()
        except Exception as e:
            Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
            self.sessions.close()
            return False

        for module in modules:
            try:
                __import__(module)
            except ImportError:
                pip.main(['install', modules[module]])
            except Exception as e:
                Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
                self.sessions.close()
                return False
        Log(20, 'Modules have been checked')
        self.sessions.close()
        return True

    def install(self) -> bool:
        Log(20, 'Bot version retrieval')
        with self.sessions.get('{0}bot/version'.format(self.URL)) as r:
            try:
                self.version = r.json()
            except Exception as e:
                Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
                self.sessions.close()
                return False
        Log(20, 'Version found: {0}'.format(self.version['Version']))

        os.makedirs('{0}/User/__Json__/'.format(self.path), 777, True)
        try:
            with open('{0}/User/__Json__/Main.json'.format(self.path), 'r') as f:
                self.main = json.load(f)
                f.close()
        except FileNotFoundError:
            with open('{0}/User/__Json__/Main.json'.format(self.path), 'w+') as f:
                self.main = {"Token": "", "Version": "0.0.0.0", "Lang": "English"}
                json.dump(self.main, f, indent=4, sort_keys=True)
                f.close()
        except Exception as e:
            Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
            self.sessions.close()
            return False

        if self.version['Version'] == self.main['Version']:
            Log(20, 'The versions found matches')
            self.sessions.close()
            return True

        Log(20, 'Launching the update')
        with self.sessions.get('{0}bot/getfile/{1}'.format(self.URL, self.version['Version'])) as r:
            try:
                file = r.json()
            except Exception as e:
                Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
                self.sessions.close()
                return False

        a = monotonic()
        b = 1024 * 512

        Log(20, 'File download')
        for c in range(len(file)):
            os.makedirs('{0}/{1}'.format(self.path, str(file[c]['path']).replace((self.version['Version']), '').replace('LargFile', 'Bot')), 777, True)
            f = open('{0}/{1}/{2}'.format(self.path, str(file[c]['path']).replace((self.version['Version']), '').replace('LargFile', 'Bot'), str(file[c]['name']).replace('.file', '.exe')), 'wb')
            with self.sessions.get('{0}botfile/version?path={1}&name={2}'.format(self.URL, file[c]['path'], file[c]['name']), stream = True) as r:
                d = (file[c]['size'] / b)
                e = 0

                if d <= 0:
                    d = 1

                for chunk in r.iter_content(b):
                    if chunk:
                        try:
                            f.write(chunk)
                        except Exception as e:
                            Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
                            self.sessions.close()
                            return False
                        e += 1
                        g = 100.0 if ((e/d)*100) > 100.0 else ((e/d)*100)
                        h = ((c/len(file))*100)+(g/len(file))
                        print('[{0}]{1}'.format((int(h)*'-'+'>')+((100-int(h))*' '), str(h)[:5]+'%'), end='\r')
                f.close()

        i = (monotonic() - a)
        j = '{0}.{1}'.format(str(i).split('.')[0], (str(i).split('.')[1])[:2])
        Log(20, 'Download completed in {0} s'.format(j), Start = '\n')

        try:
            with open('{0}/User/__Json__/Main.json'.format(self.path), 'w') as f:
                self.main["Version"] = self.version['Version']
                json.dump(self.main, f, indent=4, sort_keys=True)
                f.close()
        except Exception as e:
            Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
            self.sessions.close()
            return False
        Log(20, 'Update finished')
        self.sessions.close()
        return True