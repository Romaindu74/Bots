try:
    import requests
except:
    raise

__all__ = (
    'Options'
)

class Options:
    def add_bot(self, Id: str) -> None:...

    Path:         str
    URL:          str
    Initialized:  list
    Bots:         dict
    Info:         dict
    sessions:     requests.Session