from .Bot import Bot

__all__ = (
    'setup'
)

class setup:
    async def setup(Bot: Bot) -> bool:...