from .Interface import Interface as I
from .Options   import Options   as O
from .Statu     import Statu_    as S

try:
    from discord.ext import commands
except Exception:
    raise

__all__ = (
    'Bot'
)

class Bot:
    def Start_Bot(self) -> bool:...
    def Stop_Bot(self)  -> bool:...
    def Stop(self)      -> None:...

    Ping:      float
    check:     bool
    Id:        str
    Statu:     str
    Info:      dict
    Prefix:    dict
    Client:    commands.Bot
    Interface: I
    Options:   O
    Statu_:    S
