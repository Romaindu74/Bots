import os

from .Logger import Log

try:
    import json
except ImportError:
    Log(50, 'Module json is not found', True)
except Exception as e:
    Log(50, 'Error in file GetLang.py\nError: {0}'.format(e), True)

try:
    import requests
except ImportError:
    Log(50, 'Module requests is not found', True)
except Exception as e:
    Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e), True)

class Get_Lang:
    def _charge(self, Lang):
        path = os.path.abspath('.')

        if not Lang:
            try:
                with open('{0}/User/__Json__/Main.json'.format(path), 'r', encoding="utf-8") as f:
                    main_file = json.load(f);f.close();del f
            except FileNotFoundError:
                main_file = {'Lang': 'English'}
            except Exception as e:
                main_file = {'Lang': 'English'}
                Log(50, 'Error in file GetLang.py\nError: {0}'.format(e))
        else:
            main_file = {'Lang': Lang}

        try:
            with open('{0}/Bot/Language/{1}.json'.format(path, main_file.get('Lang', 'English')), 'r', encoding="utf-8") as f:
                self.file_lang = json.load(f);f.close();del f
        except FileNotFoundError:
            Log(20, 'File {0}.json download'.format(main_file.get('Lang')))
            os.makedirs('{0}/Bot/Language/'.format(path), 777, True)
            f = open('{0}/Bot/Language/{1}'.format(path, str(main_file.get('Lang'))+'.json'), 'wb+')
            with requests.get('https://reclinable-supervis.000webhostapp.com/botfile/language?name={0}'.format(str(main_file.get('Lang'))+'.json')) as r:
                try:
                    f.write(r.content)
                except Exception as e:
                    Log(50, "An error occurred in file {0}\nError: {1}".format(__file__, e))
                    return False
                f.close()
            Log(20, 'Download completed')

            with open('{0}/Bot/Language/{1}.json'.format(path, main_file.get('Lang', 'English')), 'r', encoding="utf-8") as f:
                self.file_lang = json.load(f);f.close();del f
        except Exception as e:
            Log(50, 'Error in file GetLang.py\nError: {0}'.format(e), True)

    @classmethod
    def get(self, __key: str, __default: str = False, Lang: str = False) -> str:
        self._charge(self, Lang)
        if __default:
            return self.file_lang.get(__key, __default)
        return self.file_lang.get(__key, Get_Lang.get(__key, 'None', 'English'))

class Get_User_Lang:
    def __init__(self, id: int, Lang: str = False):
        path = os.path.abspath('.')

        self.id = id

        if not Lang:
            os.makedirs('{0}/User/__User__/'.format(path), 777, True)
            try:
                with open('{0}/User/__User__/{1}.json'.format(path, id), 'r', encoding="utf-8") as f:
                    self.main_file = json.load(f);f.close();del f
            except FileNotFoundError:
                self.main_file = {"Lang": "English"}
                with open('{0}/User/__User__/{1}.json'.format(path, id), 'w+', encoding="utf-8") as f:
                    json.dump(self.main_file, f, indent=4);f.close();del f
            except Exception as e:
                self.main_file = {'Lang': 'English'}
                Log(50, 'Error in file GetLang.py\nError: {0}'.format(e))
        else:
            self.main_file = {"Lang": Lang}

    def get(self, __key: str, __default: str = False) -> str:
        return Get_Lang.get(__key, __default, self.main_file.get('Lang', 'English'))

    @property
    def get_lang(self) -> str:
        return self.main_file.get('Lang', 'English')