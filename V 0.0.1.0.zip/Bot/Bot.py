from .Logger         import Log
from .AddCog         import AddCog
from .GetLang        import Get_Lang

from .type.Interface import Interface
from .type.Options   import Options
from .Utils          import Open, MISSING
from .Statu          import Status

from typing          import Union
from time            import sleep

import os, asyncio

try:
    import discord
    from discord.ext import commands
except ImportError:
    Log(50, Get_Lang.get('0.0.0.0.0').format(Name = 'discord'), True)
except Exception as e:
    Log(50, Get_Lang.get('0.0.0.0.1').format(File = __file__, Error = str(e)), True)

import threading

class Bot(threading.Thread):
    def __init__(self, Id: str = MISSING, Options: Options = MISSING) -> None:
        super(Bot, self).__init__()

        self.check = False

        if Id == MISSING:
            Log(50, Get_Lang.get('0.0.1.4.9').format(Error = Get_Lang.get('0.0.1.5.0')), True)

        elif Options == MISSING:
            Log(50, Get_Lang.get('0.0.1.4.9').format(Error = Get_Lang.get('0.0.1.5.1')), True)

        else:
            self.check = True

        self.Event = 0

        self.interface_ = None
        self.id_        = Id
        self.options_   = Options

        self.statu      = Status(self, self.options_)

        if not os.path.exists('{0}/User/Bots/{1}/'.format(self.options_.Path, self.id_)):
            os.makedirs('{0}/User/Bots/{1}/'.format(self.options_.Path, self.id_), exist_ok = True)

        self.prefix_ = Open('{0}/User/Bots/{1}/Prefix.json'.format(self.options_.Path, self.id_), {'Prefix': ["!"]})
        print(self.prefix_)
        self.info_   = Open('{0}/User/Bots/{1}/Main.json'.format(self.options_.Path, self.id_), {})

        self.statu_  = '0.0.0.6.2'
        self.client_ = None
        self.ping_   = 0.0

    def run(self) -> None:
        while True:
            if self.Event == 0:
                sleep(0.5)
            elif self.Event == 1:
                self.Event = 0
                asyncio.run(self.Start_())

    async def Start_(self) -> Union[bool, None]:
        self.client_ = commands.Bot((self._prefix), intents = discord.Intents.all())

        Info = Open('{0}/User/Bots/{1}/Main.json'.format(self.options_.Path, self.id_))
        if not Info.get('Token', False):
            Log(30, Get_Lang.get('0.0.0.1.3'))
            return False

        await AddCog(self)
        self.statu.Start()

        Log(20, Get_Lang.get('0.0.0.0.7'))
        try:
            await self.client_.start(Info.get('Token'))
        except KeyboardInterrupt:
            Log(50, Get_Lang.get('0.0.1.4.6'))
            self.client_.loop.create_task(self.client_.close())
        except Exception as e:
            Log(50, Get_Lang.get('0.0.0.0.8').format(Error = e))

    def _prefix(self, client: commands.Bot, message: discord.Message) -> list:
        _prefix_ = []

        for i in self.Prefix.get('Prefix', []):
            _prefix_.append(i)

        if message.guild:
            if not os.path.exists('{0}/User/{1}/__Guilds__/{2}/'.format(self.options_.Path, client.user.id, message.guild.id)):
                os.makedirs('{0}/User/{1}/__Guilds__/{2}/'.format(self.options_.Path, client.user.id, message.guild.id), exist_ok = True)

            guild_prefix = Open('{0}/User/{1}/__Guilds__/{2}/Main.json'.format(self.options_.Path, client.user.id, message.guild.id), {'Prefix': []})
            for i in guild_prefix.get('Prefix', []):
                _prefix_.append(i)

        return _prefix_

    def Stop(self) -> None:
        if self.Statu != '0.0.0.6.2':
            self.Stop_Bot()

    def Start_Bot(self) -> bool:
        try:
            self.Event = 1
        except Exception:
            return False
        else:
            return True

    def Stop_Bot(self) -> bool:
        self.statu.Stop()

        try:
            self.client_.loop.create_task(self.client_.close())
        except Exception as e:
            return False
        else:
            Log(20, Get_Lang.get('0.0.1.7.3'))
            self.Statu = '0.0.0.6.2'
            self.Interface.UpDate_Bot(str(self.id_))
            return True

    @property
    def Options(self) -> Options:
        return self.options_

    @property
    def Interface(self) -> Union[Interface, None]:
        return self.interface_

    @Interface.setter
    def Interface(self, value: Interface) -> Interface:
        self.interface_ = value
        return self.interface_

    @property
    def Client(self) -> commands.Bot:
        return self.client_

    @property
    def Id(self) -> str:
        return self.id_

    @property
    def Info(self) -> dict:
        return self.info_

    @property
    def Prefix(self) -> dict:
        return self.prefix_

    @Prefix.setter
    def Prefix(self, value: dict) -> dict:
        self.prefix_ = value
        return self.prefix_

    @property
    def Statu_(self) -> Status:
        return self.statu

    @property
    def Statu(self) -> str:
        return self.statu_

    @Statu.setter
    def Statu(self, value: str) -> str:
        self.statu_ = value
        return self.statu_

    @property
    def Ping(self) -> float:
        return self.ping_

    @Ping.setter
    def Ping(self, value: float = MISSING) -> float:
        if not value == MISSING:
            self.ping_ = value
        return self.ping_